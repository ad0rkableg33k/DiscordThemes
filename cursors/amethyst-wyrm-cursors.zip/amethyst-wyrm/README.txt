Amethyst Wyrm cursor pack  |  by ad0rkableg33k
https://ad0rkableg33k.github.io/DiscordThemes/

pointer  - default arrow
hover    - links and buttons
loading  - busy / progress

Each cursor comes as:
  .png  - the image itself (use in themes, CSS, or other tools)
  .cur  - ready-to-use Windows cursor (Settings > Bluetooth & devices > Mouse > Additional mouse settings > Pointers > Browse)

Hotspot (the click point) in the .cur files:
  pointer: 2, 2
  hover: 10, 10
  loading: 28, 28

Note: these are already built into the matching Discord theme. This pack is for using them elsewhere.
